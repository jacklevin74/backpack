"use strict";
exports.id = 416;
exports.ids = [416];
exports.modules = {

/***/ 3416:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Posts)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8768);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_legacy_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9755);
/* harmony import */ var next_legacy_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_legacy_image__WEBPACK_IMPORTED_MODULE_2__);
/* eslint-disable max-len */ 


const articles = [
    {
        title: "CoinDesk",
        subtitle: "Heavy Demand for Madlads NFT Breaks Internet, Delays Mint",
        image: "https://www.coindesk.com/resizer/aHFTwpGDGmuTTf1AC6ueAsmJv1w=/2112x1188/filters:quality(80):format(webp)/cloudfront-us-east-1.images.arcpublishing.com/coindesk/FB4VEP3MIBCLNHHOHFWHRHCP2A.jpg",
        href: "https://www.coindesk.com/web3/2023/04/21/heavy-demand-for-madlads-nft-breaks-internet-delays-mint"
    },
    {
        title: "Fortune Crypto",
        subtitle: "Solana has outperformed Bitcoin and Ethereum since January thanks in part to Mad Lads NFTs",
        image: "https://content.fortune.com/wp-content/uploads/2023/04/Coins-Solana-6.jpg?w=1440&q=75",
        href: "https://fortune.com/crypto/2023/04/28/solana-cryptocurrency-outperforms-bitcoin-and-ethereum-ytd-mad-lads/"
    },
    {
        title: "Blockworks",
        subtitle: "So You Know What NFTs Are, but How About xNFTs?",
        image: "https://blockworks.co/_next/image?url=https%3A%2F%2Fblockworks-co.imgix.net%2Fwp-content%2Fuploads%2F2023%2F05%2FNFT-royalties.jpg&w=1920&q=75",
        href: "https://blockworks.co/news/you-know-xnfts"
    },
    {
        title: "NFTNow",
        subtitle: "What Are xNFTs? The New Type of Token Behind the Mad Lads Craze",
        image: "https://nftnow.com/wp-content/uploads/2023/04/Mad-Lads-NFTs-1-1536x1023.jpg",
        href: "https://nftnow.com/features/what-are-xnfts-the-new-type-of-token-behind-the-mad-lads-craze/"
    },
    {
        title: "Decrypt",
        subtitle: "Solana NFTs Come to Portfolio App Floor Amid Mad Lads Boom",
        image: "https://img.decrypt.co/insecure/rs:fit:1536:0:0:0/plain/https://cdn.decrypt.co/wp-content/uploads/2023/01/floor-app-2023-gID_7.png@webp",
        href: "https://decrypt.co/137634/solana-nfts-come-to-portfolio-app-floor-amid-mad-lads-boom"
    },
    {
        title: "PR Newswire",
        subtitle: "Backpack Launches First Solana xNFT Collection, Breaking Records and Showcasing an Opportunity for NFTs to Be More Than JPEGs and Reach a Mass Consumer Audience",
        image: "https://www.coindesk.com/resizer/aHFTwpGDGmuTTf1AC6ueAsmJv1w=/2112x1188/filters:quality(80):format(webp)/cloudfront-us-east-1.images.arcpublishing.com/coindesk/FB4VEP3MIBCLNHHOHFWHRHCP2A.jpg",
        href: "https://www.prnewswire.com/news-releases/backpack-launches-first-solana-xnft-collection-breaking-records-and-showcasing-an-opportunity-for-nfts-to-be-more-than-jpegs-and-reach-a-mass-consumer-audience-301807194.html"
    }
];
function Posts() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col gap-3",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "text-xl font-bold tracking-wide text-zinc-50",
                children: "News"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid w-full grid-cols-1 gap-10 md:grid-cols-2",
                children: articles.map((article, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid grid-cols-1 items-center justify-around gap-6 rounded-xl bg-zinc-800 py-8 px-8 md:grid-cols-2 md:gap-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col pr-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-xl tracking-wide text-zinc-50",
                                        children: article.title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-4 text-sm text-zinc-300",
                                        children: article.subtitle
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        target: "_blank",
                                        rel: "noreferrer",
                                        href: article.href,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "mt-4 flex cursor-pointer items-center gap-2 font-medium text-zinc-50",
                                            children: [
                                                "Read ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_1__.ArrowRightIcon, {
                                                    strokeWidth: 3,
                                                    height: 14
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_legacy_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                alt: "article-img",
                                className: "rounded-xl bg-cover object-cover",
                                src: article.image,
                                width: 500,
                                height: 340
                            })
                        ]
                    }, index))
            })
        ]
    });
}


/***/ })

};
;