"use strict";
exports.id = 958;
exports.ids = [958];
exports.modules = {

/***/ 8958:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ components_Newsletter)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@heroicons/react/outline"
var outline_ = __webpack_require__(8768);
// EXTERNAL MODULE: external "isomorphic-unfetch"
var external_isomorphic_unfetch_ = __webpack_require__(7881);
var external_isomorphic_unfetch_default = /*#__PURE__*/__webpack_require__.n(external_isomorphic_unfetch_);
;// CONCATENATED MODULE: ./lib/mailchimp.ts

/**
 * Subscribe to Mailchimp list
 * @param email
 */ async function subscribe(email) {
    await external_isomorphic_unfetch_default()(`/api/email?secret=${process.env.NEXT_PUBLIC_MY_SECRET_TOKEN}&email=${email}`);
}

;// CONCATENATED MODULE: ./components/Newsletter.tsx




function Newsletter() {
    const [email, setEmail] = (0,external_react_.useState)("");
    const [subscribed, setSubscribed] = (0,external_react_.useState)(false);
    async function subscribeEmail(e) {
        e.preventDefault();
        // TODO: improve error handling
        try {
            await subscribe(email);
            setEmail("");
            setSubscribed(true);
        } catch  {
        // Pass
        }
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "mx-auto py-12",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "rounded-lg bg-teal-600 px-6 py-6 md:py-12 md:px-12 lg:py-16 lg:px-16 xl:flex xl:items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "xl:w-0 xl:flex-1",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "text-2xl font-extrabold tracking-tight text-zinc-50 sm:text-3xl",
                                children: "Want Backpack news and updates?"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "mt-3 max-w-3xl text-lg leading-6 text-teal-200",
                                children: "Sign up for our Substack to stay up to date."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mt-8 sm:w-full sm:max-w-md xl:mt-0 xl:ml-8",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                className: "sm:flex",
                                onSubmit: subscribeEmail,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "email-address",
                                        className: "sr-only",
                                        children: "Email address"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        id: "email-address",
                                        name: "email-address",
                                        type: "email",
                                        autoComplete: "email",
                                        value: email,
                                        onChange: (e)=>setEmail(e.target.value),
                                        required: true,
                                        className: "block w-full rounded-md border-0 px-4 py-3 text-base text-gray-900 placeholder-gray-500",
                                        placeholder: "Enter your email"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "submit",
                                        className: "mt-3 flex w-32 items-center justify-center rounded-md border border-teal-500 bg-teal-500 text-base font-medium text-teal-50 shadow hover:bg-teal-400 sm:mt-0 sm:ml-3",
                                        children: subscribed ? /*#__PURE__*/ jsx_runtime_.jsx(outline_.CheckIcon, {
                                            className: "h-8 w-8"
                                        }) : "Notify me"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "mt-3 text-sm text-teal-200",
                                children: subscribed ? "You’ll be the first to know when Backpack is ready." : "We hate spam as much as you do."
                            })
                        ]
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const components_Newsletter = (/*#__PURE__*/(0,external_react_.memo)(Newsletter));


/***/ })

};
;