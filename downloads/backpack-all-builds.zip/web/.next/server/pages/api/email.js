"use strict";
(() => {
var exports = {};
exports.id = 846;
exports.ids = [846];
exports.modules = {

/***/ 7878:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "@mailchimp/mailchimp_marketing"
const mailchimp_marketing_namespaceObject = require("@mailchimp/mailchimp_marketing");
var mailchimp_marketing_default = /*#__PURE__*/__webpack_require__.n(mailchimp_marketing_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/email.ts

mailchimp_marketing_default().setConfig({
    apiKey: process.env.MAILCHIMP_API_KEY,
    server: process.env.MAILCHIMP_SERVER_PREFIX
});
const listID = process.env.MAILCHIMP_LISTID;
async function handler(req, res) {
    // Check for secret to confirm this is a valid request
    if (req.query.secret !== process.env.NEXT_PUBLIC_MY_SECRET_TOKEN) {
        return res.status(401).json({
            message: "Invalid token"
        });
    }
    const email = req.query.email;
    try {
        const response = await mailchimp_marketing_default().lists.addListMember(listID, {
            email_address: email,
            status: "pending"
        });
        return res.end();
    } catch (err) {
        console.error("Error subscribing:", err);
        return res.status(500).send("Error subscribing email");
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7878));
module.exports = __webpack_exports__;

})();